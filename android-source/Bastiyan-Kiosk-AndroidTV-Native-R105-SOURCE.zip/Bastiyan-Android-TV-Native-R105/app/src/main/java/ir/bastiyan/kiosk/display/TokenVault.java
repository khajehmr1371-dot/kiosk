package ir.bastiyan.kiosk.display;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** AES-GCM Android Keystore; never writes passwords or raw bearer tokens to preferences. */
final class TokenVault {
    private static final String ALIAS="bastiyan_display_session_v1";
    private static final String PREFERENCES="bastiyan_display_private";
    private final SharedPreferences prefs;
    TokenVault(Context ctx){prefs=ctx.getSharedPreferences(PREFERENCES,Context.MODE_PRIVATE);}
    String server(){return prefs.getString("server","");}
    String username(){return prefs.getString("username","");}
    String centerId(){return prefs.getString("centerId","");}
    String centerName(){return prefs.getString("centerName","باستیان کیوسک");}
    boolean audioEnabled(){return prefs.getBoolean("audioEnabled",true);}
    void setAudioEnabled(boolean on){prefs.edit().putBoolean("audioEnabled",on).apply();}
    String lastPlayedId(){return prefs.getString("lastPlayedCallId","");}
    void markPlayed(String id){prefs.edit().putString("lastPlayedCallId",id).apply();}
    private SecretKey key()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return gen.generateKey();
    }
    void saveSession(String server,String username,String centerId,String centerName,String token)throws Exception{
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=c.doFinal(token.getBytes(StandardCharsets.UTF_8));
        prefs.edit().putString("server",server).putString("username",username)
            .putString("centerId",centerId).putString("centerName",centerName)
            .putString("token",Base64.encodeToString(encrypted,Base64.NO_WRAP))
            .putString("iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).apply();
    }
    String token(){
        try{
            String raw=prefs.getString("token","");String iv=prefs.getString("iv","");
            if(raw.isEmpty()||iv.isEmpty())return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.DEFAULT)));
            return new String(c.doFinal(Base64.decode(raw,Base64.DEFAULT)),StandardCharsets.UTF_8);
        }catch(Exception ignored){return "";}
    }
    /** Cache only public doctor labels + ticket numbers; never save patient names, notes or national IDs. */
    void saveAnonymousState(JSONObject state){
        if(state==null)return;
        try{
            JSONObject sanitized=new JSONObject();
            sanitized.put("version",state.optLong("version",0));
            JSONArray docs=new JSONArray(),srcDocs=state.optJSONArray("doctors");
            if(srcDocs!=null)for(int i=0;i<Math.min(srcDocs.length(),50);i++){
                JSONObject d=srcDocs.optJSONObject(i);if(d==null)continue;
                docs.put(new JSONObject().put("id",d.optString("id"))
                    .put("name",d.optString("name")).put("specialty",d.optString("specialty")));
            }
            JSONArray queues=new JSONArray(),srcQueues=state.optJSONArray("queues");
            if(srcQueues!=null)for(int i=0;i<Math.min(srcQueues.length(),500);i++){
                JSONObject q=srcQueues.optJSONObject(i);if(q==null)continue;
                queues.put(new JSONObject().put("doctorId",q.optString("doctorId"))
                    .put("number",q.optInt("number",q.optInt("queueNumber",0)))
                    .put("status",q.optString("status")).put("isActive",q.optBoolean("isActive",true)));
            }
            sanitized.put("doctors",docs);sanitized.put("queues",queues);
            // Never retain announcement audio events or tokens in cache.
            prefs.edit().putString("publicSnapshot",sanitized.toString())
                .putLong("snapshotAt",System.currentTimeMillis()).apply();
        }catch(Exception ignored){}
    }
    JSONObject cachedAnonymousState(){
        try{
            String raw=prefs.getString("publicSnapshot","");
            if(raw.isEmpty()||System.currentTimeMillis()-cachedSnapshotTime()>24*3600*1000L)return null;
            return new JSONObject(raw);
        }catch(Exception e){return null;}
    }
    long cachedSnapshotTime(){return prefs.getLong("snapshotAt",0L);}
    void forgetSession(){prefs.edit().remove("token").remove("iv").remove("centerId").apply();}
    void saveServer(String server){prefs.edit().putString("server",server).apply();}
}
