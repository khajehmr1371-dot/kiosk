package ir.bastiyan.kiosk.display;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Only HTTPS, same-origin, official Bastiyan Kiosk API. No WebView or browser. */
public final class KioskApi {
    public static final class ApiException extends Exception {
        public final int httpStatus;
        ApiException(String message, int status){ super(message); httpStatus=status; }
    }
    private final String origin;
    public KioskApi(String raw){ origin=normalizeOrigin(raw); }
    public String origin(){ return origin; }

    public static String normalizeOrigin(String raw){
        try {
            URI uri=new URI(raw==null?"":raw.trim());
            if(!"https".equalsIgnoreCase(uri.getScheme())||uri.getHost()==null||
                uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null||
                (uri.getRawPath()!=null&&!uri.getRawPath().isEmpty()&&!"/".equals(uri.getRawPath()))||
                (uri.getPort()!=-1&&uri.getPort()!=443)) throw new IllegalArgumentException();
            return "https://"+uri.getHost().toLowerCase(Locale.ROOT);
        }catch(Exception e){ throw new IllegalArgumentException("نشانی باید HTTPS اصلی سامانه، بدون مسیر اضافی یا رمز باشد"); }
    }
    private JSONObject request(String route, String token, JSONObject payload) throws Exception {
        HttpURLConnection c=null;
        try {
            URL url=new URL(origin+"/api/"+route);
            c=(HttpURLConnection)url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(8000); c.setReadTimeout(10000);
            c.setUseCaches(false);
            c.setRequestProperty("Accept","application/json");
            c.setRequestProperty("User-Agent","BastiyanKioskNativeAndroidTV/1.0.5");
            if(token!=null&&!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
            c.setRequestMethod(payload==null?"GET":"POST");
            if(payload!=null){
                byte[] b=payload.toString().getBytes(StandardCharsets.UTF_8);
                if(b.length>16384)throw new ApiException("درخواست بیش از حد بزرگ است",0);
                c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                c.setFixedLengthStreamingMode(b.length);
                try(OutputStream out=c.getOutputStream()){out.write(b);}
            }
            int code=c.getResponseCode();
            if(code>=300&&code<400)throw new ApiException("سرور درخواست را به نشانی دیگری هدایت کرد؛ آدرس سامانه را بررسی کنید",code);
            String type=c.getContentType();
            if(type==null||!type.toLowerCase(Locale.ROOT).contains("json"))
                throw new ApiException("به جای API، پاسخ غیر JSON دریافت شد؛ آدرس یا تنظیمات سرویس اشتباه است (HTTP "+code+")",code);
            byte[] data;
            try(InputStream in=code>=400?c.getErrorStream():c.getInputStream()){
                if(in==null)throw new ApiException("پاسخی از سرور دریافت نشد",code);
                ByteArrayOutputStream buffer=new ByteArrayOutputStream(); byte[] b=new byte[8192];int n;
                while((n=in.read(b))!=-1){if(buffer.size()+n>2_000_000)throw new ApiException("پاسخ سرور بیش از حد بزرگ است",code);buffer.write(b,0,n);}
                data=buffer.toByteArray();
            }
            JSONObject j=new JSONObject(new String(data,StandardCharsets.UTF_8));
            if(code>=400||j.optBoolean("success",true)==false){
                String message=j.optString("error",j.optString("message","HTTP "+code));
                throw new ApiException(message,code);
            }
            return j;
        }finally{if(c!=null)c.disconnect();}
    }
    public JSONObject health()throws Exception{
        JSONObject j=request("health",null,null);
        if(!"ok".equals(j.optString("status"))||!"bastian_clinic_queue_system".equals(j.optString("service")))
            throw new ApiException("این نشانی به سرور اصلی کیوسک باستیان متصل نیست",0);
        return j;
    }
    public JSONObject login(String username,String password)throws Exception{
        JSONObject p=new JSONObject();p.put("username",username);p.put("password",password);
        JSONObject j=request("auth/display-login",null,p);
        if(!j.optBoolean("success",false)||!"display".equals(j.optString("role"))||
           j.optString("token").length()<24||j.optString("centerId").isEmpty())
            throw new ApiException("سرور نشست معتبر مخصوص نمایشگر صادر نکرد",0);
        return j;
    }
    public JSONObject state(String token,String centerId)throws Exception{
        JSONObject j=request("state",token,null);
        if(!j.optBoolean("success",false)||!"display".equals(j.optString("authRole"))||
           !centerId.equals(j.optString("centerId"))||j.optJSONArray("doctors")==null||j.optJSONArray("queues")==null)
            throw new ApiException("نشست یا داده دریافتی با نمایشگر این مرکز مطابقت ندارد",403);
        return j;
    }
    public JSONObject poll(String token,long version)throws Exception{
        return request("sync/poll?version="+Math.max(0,version),token,null);
    }
    public void complete(String token,String callId)throws Exception{
        JSONObject p=new JSONObject().put("callId",callId);
        JSONObject j=request("announcements/complete",token,p);
        if(!j.optBoolean("success",false))throw new ApiException("تأیید فراخوان به سرور نرسید",0);
    }
    public void keepalive(String token)throws Exception{request("session/keepalive",token,new JSONObject());}
}
