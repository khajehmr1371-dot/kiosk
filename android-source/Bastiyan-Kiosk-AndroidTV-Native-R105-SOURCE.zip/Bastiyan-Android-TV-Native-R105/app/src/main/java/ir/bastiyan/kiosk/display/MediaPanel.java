package ir.bastiyan.kiosk.display;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Browser-free display of supported same-origin images and videos, with safe queue fallback. */
final class MediaPanel extends FrameLayout {
    interface Visibility { void changed(boolean visible); }
    private static final class Clip {
        final String kind,url,key; final int duration;
        Clip(String kind,String url,String key,int duration){this.kind=kind;this.url=url;this.key=key;this.duration=duration;}
    }
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService downloads=Executors.newSingleThreadExecutor();
    private final ArrayList<Clip> playlist=new ArrayList<>();
    private final Visibility visibility;
    private final TextView overlay;
    private final Runnable advance=new Runnable(){@Override public void run(){next();}};
    private boolean enabled=false,ducked=false,visible=false;
    private String signature="",origin="",token="";
    private int index=-1,failures=0,generation=0;
    private VideoView video;
    private MediaPlayer videoPlayer;
    private float normalVolume=0.7f;

    MediaPanel(Context ctx,Visibility callback){
        super(ctx);visibility=callback;setBackgroundColor(Color.rgb(7,17,29));
        overlay=new TextView(ctx);overlay.setTextColor(Color.rgb(255,229,136));
        overlay.setTextSize(48);overlay.setGravity(Gravity.CENTER);
        overlay.setBackgroundColor(Color.argb(215,4,17,29));overlay.setVisibility(View.GONE);
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        op.leftMargin=30;op.rightMargin=30;addView(overlay,op);
        setVisibility(View.GONE);
    }
    private void visible(boolean value){
        if(visible==value)return;
        visible=value;setVisibility(value?View.VISIBLE:View.GONE);visibility.changed(value);
    }
    void configure(JSONObject state,String allowedOrigin,String bearerToken,boolean connected){
        if(!connected||state==null){stop();return;}
        JSONObject settings=state.optJSONObject("settings");
        JSONObject display=settings==null?null:settings.optJSONObject("displaySettings");
        if(display==null||!"media".equals(display.optString("mode","queue"))){stop();return;}
        JSONArray raw=display.optJSONArray("mediaPlaylist");
        ArrayList<Clip> next=new ArrayList<>();StringBuilder sig=new StringBuilder();
        if(raw!=null)for(int i=0;i<Math.min(raw.length(),100);i++){
            JSONObject j=raw.optJSONObject(i);if(j==null||!j.optBoolean("active",true))continue;
            String type=j.optString("type"),url=j.optString("url"),id=j.optString("id");
            if(!("image".equals(type)||"video".equals(type)))continue;
            if(!url.startsWith("/api/media/file?")||url.contains("#")||url.contains("\\"))continue;
            int duration=Math.max(3,Math.min(120,j.optInt("duration",12)));
            next.add(new Clip(type,url,id,duration));sig.append(id).append(':').append(url).append(';');
        }
        if(next.isEmpty()){stop();return;}
        String sigValue=sig.toString();
        origin=allowedOrigin;token=bearerToken;
        normalVolume=(float)Math.max(0,Math.min(1,display.optDouble("mediaVolume",0.7)));
        setVideoVolume();
        if(enabled&&sigValue.equals(signature))return;
        stop();enabled=true;signature=sigValue;playlist.addAll(next);index=-1;failures=0;
        next();
    }
    private void next(){
        if(!enabled||playlist.isEmpty())return;
        ui.removeCallbacks(advance);visible(false);clearVisual();
        index=(index+1)%playlist.size();
        Clip clip=playlist.get(index);int expected=++generation;
        if("image".equals(clip.kind))loadImage(clip,expected);
        else loadVideo(clip,expected);
    }
    private void clearVisual(){
        ui.removeCallbacks(advance);videoPlayer=null;
        if(video!=null){try{video.stopPlayback();}catch(Exception ignored){}video=null;}
        removeAllViews();addOverlay();
    }
    private void addOverlay(){
        // Re-adding keeps call number above images and video surfaces.
        if(overlay.getParent()!=null)((FrameLayout)overlay.getParent()).removeView(overlay);
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        op.leftMargin=30;op.rightMargin=30;addView(overlay,op);
    }
    private void loadImage(Clip clip,int expected){
        final String requestUrl=origin+clip.url,headerToken=token;
        downloads.execute(()->{
            Bitmap bitmap=null;
            HttpURLConnection conn=null;
            try{
                conn=(HttpURLConnection)new URL(requestUrl).openConnection();conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(7000);conn.setReadTimeout(12000);
                if(!headerToken.isEmpty())conn.setRequestProperty("Authorization","Bearer "+headerToken);
                int status=conn.getResponseCode();
                if(status!=200)throw new IllegalArgumentException("HTTP "+status);
                if(conn.getContentLength()>15_000_000)throw new IllegalArgumentException("Image too large");
                try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] bytes=new byte[16384];int n;
                    while((n=in.read(bytes))!=-1){if(out.size()+n>15_000_000)throw new IllegalArgumentException("Image too large");out.write(bytes,0,n);}
                    byte[] data=out.toByteArray();
                    BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
                    BitmapFactory.decodeByteArray(data,0,data.length,options);
                    int sample=1;while(options.outWidth/sample>2400||options.outHeight/sample>1600)sample*=2;
                    options.inSampleSize=sample;options.inJustDecodeBounds=false;
                    bitmap=BitmapFactory.decodeByteArray(data,0,data.length,options);
                }
                if(bitmap==null)throw new IllegalArgumentException("Unsupported image format");
            }catch(Exception ignored){}
            finally{if(conn!=null)conn.disconnect();}
            final Bitmap image=bitmap;
            ui.post(()->{
                if(expected!=generation||!enabled){if(image!=null)image.recycle();return;}
                if(image==null){failed();return;}
                ImageView view=new ImageView(getContext());view.setImageBitmap(image);
                view.setScaleType(ImageView.ScaleType.FIT_CENTER);
                addView(view,0,new FrameLayout.LayoutParams(-1,-1));
                failures=0;visible(true);
                ui.postDelayed(advance,clip.duration*1000L);
            });
        });
    }
    private void loadVideo(Clip clip,int expected){
        try{
            video=new VideoView(getContext());
            addView(video,0,new FrameLayout.LayoutParams(-1,-1));
            video.setOnPreparedListener(mp->{
                if(expected!=generation||!enabled)return;
                videoPlayer=mp;setVideoVolume();failures=0;visible(true);video.start();
                // Long/broken media never blocks queue visibility indefinitely.
                ui.postDelayed(()->{if(expected==generation)next();},Math.max(30,Math.min(3600,clip.duration))*1000L);
            });
            video.setOnCompletionListener(mp->{if(expected==generation)ui.post(advance);});
            video.setOnErrorListener((mp,what,extra)->{if(expected==generation)ui.post(this::failed);return true;});
            video.setVideoURI(Uri.parse(origin+clip.url));
        }catch(Exception ignored){failed();}
    }
    private void setVideoVolume(){
        if(videoPlayer!=null){float v=ducked?0f:normalVolume;
            try{videoPlayer.setVolume(v,v);}catch(Exception ignored){}
        }
    }
    void setAnnouncementActive(boolean active){ducked=active;setVideoVolume();}
    void showCall(int number){
        if(!enabled)return;
        overlay.setText("فراخوان نوبت «"+persian(number)+"»");overlay.setVisibility(View.VISIBLE);
        ui.postDelayed(()->overlay.setVisibility(View.GONE),9000);
    }
    private static String persian(int n){String s=Integer.toString(n),a="0123456789",b="۰۱۲۳۴۵۶۷۸۹";
        for(int i=0;i<10;i++)s=s.replace(a.charAt(i),b.charAt(i));return s;}
    private void failed(){
        if(!enabled)return;
        failures++;visible(false);
        if(failures>=playlist.size()){stop();return;}
        ui.postDelayed(advance,1500);
    }
    void stop(){
        enabled=false;generation++;ui.removeCallbacks(advance);clearVisual();
        playlist.clear();signature="";index=-1;failures=0;
        visible(false);overlay.setVisibility(View.GONE);
    }
    void shutdown(){stop();downloads.shutdownNow();}
}
