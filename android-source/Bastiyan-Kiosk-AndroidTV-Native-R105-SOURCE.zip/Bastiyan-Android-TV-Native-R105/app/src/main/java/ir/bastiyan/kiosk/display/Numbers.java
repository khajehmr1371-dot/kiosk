package ir.bastiyan.kiosk.display;

import java.util.ArrayList;
import java.util.List;

/** Offline Farsi number fragments, up to 9999, with no OS speech service dependency. */
public final class Numbers {
    private Numbers(){}
    public static List<String> files(int number){
        if(number<1||number>9999)throw new IllegalArgumentException("Only 1..9999 supported offline");
        ArrayList<String> parts=new ArrayList<>();
        if(number<=50){parts.add(String.format(java.util.Locale.ROOT,"audio/N%02d.mp3",number));return parts;}
        parts.add("words/number.mp3");
        addUnder10000(parts,number);
        return parts;
    }
    private static void addUnder10000(List<String> list,int value){
        if(value>=1000){
            int thousands=value/1000;
            list.add("words/"+thousands+".mp3");list.add("words/1000.mp3");
            value%=1000;
            if(value>0)list.add("words/and.mp3");
        }
        if(value>=100){
            int hundreds=value/100*100;
            list.add("words/"+hundreds+".mp3");value%=100;
            if(value>0)list.add("words/and.mp3");
        }
        if(value>=20){
            int tens=value/10*10;
            list.add("words/"+tens+".mp3");value%=10;
            if(value>0)list.add("words/and.mp3");
        }
        if(value>0)list.add("words/"+value+".mp3");
    }
}
