package ir.bastiyan.kiosk.display;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Fully native Android/Android TV client. No WebView, JavaScript, LAN bridge or browser. */
public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(6,18,31), SURFACE=Color.rgb(17,44,62);
    private static final int TEXT=Color.rgb(239,248,255), SUB=Color.rgb(166,193,213);
    private static final int CYAN=Color.rgb(67,212,222), YELLOW=Color.rgb(255,214,112);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private TokenVault vault;
    private KioskApi api;
    private AudioAnnouncer announcer;
    private String token="",centerId="",centerName="باستیان کیوسک",lastCallId="",ackPending="";
    private JSONObject lastState;
    private long version=0,lastSyncedMs=0,lastKeepaliveMs=0;
    private int failureCount=0,pollCount=0;
    private boolean started=false,inFlight=false,loginBusy=false,tv=false,connected=false,displaying=false;
    private LinearLayout root,cardHost;
    private TextView statusText,clockText,tickerText,footerText,siteTitle,setupError;
    private Button soundButton;
    private MediaPanel mediaPanel;
    private EditText serverField,userField,passField;
    private final Runnable polling=new Runnable(){@Override public void run(){pollOnce();}};
    private final Runnable clockUpdater=new Runnable(){@Override public void run(){
        if(clockText!=null)clockText.setText(new SimpleDateFormat("HH:mm",Locale.ROOT){{setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));}}.format(new Date()));
        ui.postDelayed(this,20000);
    }};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tv=getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK)
            ||(getResources().getConfiguration().uiMode&Configuration.UI_MODE_TYPE_MASK)==Configuration.UI_MODE_TYPE_TELEVISION;
        if(tv){
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
        vault=new TokenVault(this);announcer=new AudioAnnouncer(this);
        token=vault.token();centerId=vault.centerId();centerName=vault.centerName();
        lastCallId=vault.lastPlayedId();ackPending=lastCallId;
        lastState=vault.cachedAnonymousState();
        lastSyncedMs=vault.cachedSnapshotTime();
        if(!vault.server().isEmpty()&&!token.isEmpty()&&!centerId.isEmpty()){
            try{api=new KioskApi(vault.server());buildDisplay();}
            catch(Exception e){buildSetup(e.getMessage());}
        } else buildSetup("برای آغاز، نشانی سامانه و مشخصات نمایشگر مرکز را وارد کنید.");
        ui.post(clockUpdater);
    }
    @Override protected void onResume(){super.onResume();started=true;if(displaying){connected=false;rebuildCards();refreshStatus("در حال بررسی اتصال مجدد…");reschedule(0);}}
    @Override protected void onPause(){started=false;connected=false;ui.removeCallbacks(polling);announcer.stop();if(mediaPanel!=null)mediaPanel.stop();super.onPause();}
    @Override protected void onDestroy(){started=false;ui.removeCallbacksAndMessages(null);announcer.stop();if(mediaPanel!=null)mediaPanel.shutdown();io.shutdownNow();super.onDestroy();}
    @Override public void onConfigurationChanged(Configuration newConfig){super.onConfigurationChanged(newConfig);if(displaying)rebuildCards();}
    @Override public boolean onKeyDown(int code,KeyEvent event){
        if(displaying&&code==KeyEvent.KEYCODE_MENU){showSettings();return true;}
        return super.onKeyDown(code,event);
    }
    private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private TextView label(String content,int sp,int color,boolean bold){
        TextView x=new TextView(this);x.setText(content);x.setTextColor(color);
        x.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);x.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        x.setTextDirection(View.TEXT_DIRECTION_RTL);
        if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return x;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View v,int a,int b){v.setPadding(dp(a),dp(b),dp(a),dp(b));}
    private void append(LinearLayout parent,View child,int h){parent.addView(child,new LinearLayout.LayoutParams(-1,h<0?h:dp(h)));}
    private Button button(String title){
        Button b=new Button(this);b.setText(title);b.setTextColor(TEXT);b.setTextSize(tv?17:14);
        b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(27,80,108)));
        b.setFocusable(true);b.setFocusableInTouchMode(true);return b;
    }
    private void base(){
        if(mediaPanel!=null){mediaPanel.shutdown();mediaPanel=null;}
        root=vertical();root.setBackgroundColor(BG);pad(root,tv?22:12,tv?12:8);
        setContentView(root);
        statusText=null;clockText=null;tickerText=null;footerText=null;cardHost=null;
    }
    private EditText field(String hint,String value,int type){
        EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);
        e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(SUB);e.setTextSize(tv?20:17);
        e.setPadding(dp(12),dp(9),dp(12),dp(9));e.setInputType(type);e.setSelectAllOnFocus(false);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN));
        return e;
    }
    private void buildSetup(String notice){
        displaying=false;ui.removeCallbacks(polling);announcer.stop();base();
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout outer=vertical();outer.setGravity(Gravity.CENTER);pad(outer,12,16);sc.addView(outer);
        LinearLayout form=vertical();pad(form,18,22);form.setBackgroundColor(SURFACE);
        LinearLayout.LayoutParams frame=new LinearLayout.LayoutParams(-1,-2);
        if(tv){frame.width=dp(650);frame.gravity=Gravity.CENTER;}
        outer.addView(form,frame);
        TextView brand=label("باستیان | نمایشگر هوشمند",tv?35:25,CYAN,true);brand.setGravity(Gravity.CENTER);
        append(form,brand,64);
        TextView subtitle=label("برنامه مستقل Android TV و اندروید — بدون مرورگر",tv?17:13,SUB,false);
        subtitle.setGravity(Gravity.CENTER);append(form,subtitle,40);
        siteTitle=subtitle;
        TextView urlLabel=label("نشانی HTTPS سامانه کیوسک",tv?18:15,TEXT,true);append(form,urlLabel,36);
        serverField=field("https://your-kiosk.example",vault.server(),InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        append(form,serverField,55);
        TextView userLabel=label("نام کاربری نمایشگر مرکز",tv?18:15,TEXT,true);append(form,userLabel,40);
        userField=field("نام کاربری مرکز",vault.username(),InputType.TYPE_CLASS_TEXT);append(form,userField,55);
        TextView passLabel=label("رمز عبور اختصاصی نمایشگر",tv?18:15,TEXT,true);append(form,passLabel,40);
        passField=field("رمز عبور", "",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        append(form,passField,55);
        Button connect=button("آزمایش اتصال و ورود به نمایشگر");append(form,connect,68);
        setupError=label(notice==null?"":notice,tv?16:13,YELLOW,false);setupError.setGravity(Gravity.CENTER);
        setupError.setMinHeight(dp(60));append(form,setupError,80);
        TextView help=label("نشانی را از سرویس اصلی کیوسک وارد کنید. ورود فقط با نقش «نمایشگر» پذیرفته می‌شود؛ هیچ رمز عبوری ذخیره نمی‌شود.",tv?15:12,SUB,false);
        help.setGravity(Gravity.CENTER);form.addView(help);
        connect.setOnClickListener(v->signIn(connect));
        // TV remote: each editable input and the final button use native D-pad focus.
        if(tv)serverField.requestFocus();
    }
    private void signIn(Button button){
        if(loginBusy)return;
        final String server=serverField.getText().toString().trim();
        final String username=userField.getText().toString().trim();
        final String password=passField.getText().toString();
        if(username.isEmpty()||password.isEmpty()){setupError.setText("نام کاربری و رمز نمایشگر را کامل وارد کنید");return;}
        final KioskApi candidate;
        try{candidate=new KioskApi(server);}catch(Exception e){setupError.setText(e.getMessage());return;}
        loginBusy=true;button.setEnabled(false);setupError.setText("در حال بررسی HTTPS و ورود به سامانه…");
        io.execute(()->{
            try{
                candidate.health();
                JSONObject login=candidate.login(username,password);
                String newToken=login.getString("token"),newCenter=login.getString("centerId");
                JSONObject state=candidate.state(newToken,newCenter);
                vault.saveSession(candidate.origin(),username,newCenter,login.optString("centerName","مرکز باستیان"),newToken);
                ui.post(()->{
                    loginBusy=false;api=candidate;token=newToken;centerId=newCenter;
                    centerName=login.optString("centerName","مرکز باستیان");
                    lastState=state;vault.saveAnonymousState(state);version=state.optLong("version",0);lastSyncedMs=System.currentTimeMillis();
                    failureCount=0;connected=true;inFlight=false;pollCount=0;passField.setText("");buildDisplay();
                });
            }catch(Exception e){
                final String reason=humanError(e);
                ui.post(()->{loginBusy=false;button.setEnabled(true);setupError.setText(reason);});
            }
        });
    }
    private void buildDisplay(){
        displaying=true;base();
        LinearLayout header=horizontal();header.setGravity(Gravity.CENTER_VERTICAL);append(root,header,tv?79:67);
        TextView emblem=label("◉",tv?31:25,CYAN,true);
        emblem.setGravity(Gravity.CENTER);header.addView(emblem,new LinearLayout.LayoutParams(dp(42),-1));
        siteTitle=label(centerName,tv?28:20,TEXT,true);
        header.addView(siteTitle,new LinearLayout.LayoutParams(0,-1,1));
        clockText=label("--:--",tv?32:19,YELLOW,true);
        clockText.setGravity(Gravity.CENTER);header.addView(clockText,new LinearLayout.LayoutParams(dp(tv?96:65),-1));
        soundButton=button(vault.audioEnabled()?"🔊 صدا روشن":"🔇 صدا خاموش");
        header.addView(soundButton,new LinearLayout.LayoutParams(dp(tv?172:116),dp(tv?55:50)));
        soundButton.setOnClickListener(v->{boolean next=!vault.audioEnabled();vault.setAudioEnabled(next);
            if(!next){announcer.stop();if(mediaPanel!=null)mediaPanel.setAnnouncementActive(false);}soundButton.setText(next?"🔊 صدا روشن":"🔇 صدا خاموش");});
        Button settings=button("⚙ تنظیمات");header.addView(settings,new LinearLayout.LayoutParams(dp(tv?154:107),dp(tv?55:50)));
        settings.setOnClickListener(v->showSettings());
        statusText=label("در حال دریافت صف…",tv?16:12,SUB,false);
        statusText.setGravity(Gravity.CENTER);append(root,statusText,tv?38:28);
        FrameLayout stage=new FrameLayout(this);
        root.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
        ScrollView viewport=new ScrollView(this);viewport.setFillViewport(true);
        stage.addView(viewport,new FrameLayout.LayoutParams(-1,-1));
        cardHost=vertical();cardHost.setGravity(Gravity.CENTER);viewport.addView(cardHost);
        mediaPanel=new MediaPanel(this,show->viewport.setVisibility(show?View.GONE:View.VISIBLE));
        stage.addView(mediaPanel,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout bottom=vertical();bottom.setBackgroundColor(Color.rgb(10,34,47));pad(bottom,15,8);
        append(root,bottom,tv?100:84);
        tickerText=label("نوبت خود را دنبال کنید — با تشکر از شکیبایی شما",tv?23:16,YELLOW,true);
        tickerText.setSingleLine(true);tickerText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tickerText.setMarqueeRepeatLimit(-1);tickerText.setSelected(true);
        append(bottom,tickerText,tv?43:35);
        footerText=label("باستیان کیوسک • نمایشگر مستقل اندروید",tv?14:11,SUB,false);
        append(bottom,footerText,tv?37:28);
        rebuildCards();refreshStatus();
        reschedule(0);
    }
    private void showSettings(){
        final String[] choices={vault.audioEnabled()?"خاموش‌کردن صدا":"روشن‌کردن صدا",
            "بررسی فوری اتصال","تغییر سرور یا حساب نمایشگر","بستن منو"};
        new AlertDialog.Builder(this).setTitle("تنظیمات نمایشگر باستیان")
            .setItems(choices,(dialog,which)->{
                if(which==0){boolean enabled=!vault.audioEnabled();vault.setAudioEnabled(enabled);
                    if(!enabled){announcer.stop();if(mediaPanel!=null)mediaPanel.setAnnouncementActive(false);}if(soundButton!=null)soundButton.setText(enabled?"🔊 صدا روشن":"🔇 صدا خاموش");}
                if(which==1)reschedule(0);
                if(which==2)new AlertDialog.Builder(this).setTitle("تغییر حساب نمایشگر")
                    .setMessage("برای محافظت از نشست، ورود مجدد لازم است. شماره نوبت بیماران حذف نمی‌شود.")
                    .setPositiveButton("ورود مجدد",(d,w)->{vault.forgetSession();token="";lastState=null;version=0;buildSetup("تنظیمات سرور و ورود را انجام دهید");})
                    .setNegativeButton("انصراف",null).show();
            }).show();
    }
    private void reschedule(long delay){ui.removeCallbacks(polling);if(started&&displaying)ui.postDelayed(polling,delay);}
    private void pollOnce(){
        if(!started||!displaying||inFlight||api==null||token.isEmpty())return;
        inFlight=true;
        final String validToken=token;final KioskApi currentApi=api;final boolean full=lastState==null||pollCount++%24==0;
        final long currentVersion=version;
        io.execute(()->{
            try{
                JSONObject response=full?currentApi.state(validToken,centerId):currentApi.poll(validToken,currentVersion);
                if(!full&&response.optBoolean("hasUpdate",false)){
                    // Always validate role+center identity on updates, never trust a partial poll as full state.
                    response=currentApi.state(validToken,centerId);
                }
                if(System.currentTimeMillis()-lastKeepaliveMs>12*3600*1000L){
                    currentApi.keepalive(validToken);lastKeepaliveMs=System.currentTimeMillis();
                }
                final JSONObject result=response;
                ui.post(()->{
                    if(!displaying||!validToken.equals(token)){inFlight=false;return;}
                    if(full||result.optJSONArray("doctors")!=null){
                        lastState=result;vault.saveAnonymousState(result);
                        version=result.optLong("version",version);
                        rebuildCards();
                    } else version=result.optLong("version",version);
                    lastSyncedMs=System.currentTimeMillis();connected=true;failureCount=0;
                    refreshStatus();
                    JSONObject bus=result.optJSONObject("announcementBus");
                    JSONObject call=bus!=null?bus.optJSONObject("current"):result.optJSONObject("triggerAnnouncement");
                    if(call!=null)checkCall(call);
                    inFlight=false;reschedule(2400);
                });
            }catch(Exception exception){
                String problem=humanError(exception);
                int status=exception instanceof KioskApi.ApiException?((KioskApi.ApiException)exception).httpStatus:0;
                ui.post(()->{
                    if(!validToken.equals(token))return;
                    inFlight=false;connected=false;failureCount++;
                    if(status==401||status==403){
                        announcer.stop();vault.forgetSession();token="";lastState=null;version=0;
                        buildSetup("نشست نمایشگر پذیرفته نشد: "+problem+". دوباره وارد شوید.");
                        return;
                    }
                    refreshStatus(problem);
                    reschedule(Math.min(30000,2500L*(1L<<Math.min(4,failureCount))));
                });
            }
        });
    }
    private void refreshStatus(){refreshStatus("");}
    private void refreshStatus(String error){
        if(statusText==null)return;
        if(!connected&&mediaPanel!=null)mediaPanel.stop();
        if(connected){
            statusText.setText("● اتصال امن برقرار است  ·  همگام‌سازی خودکار صف فعال");statusText.setTextColor(CYAN);
        }else{
            statusText.setText("⚠ ارتباط با سرور برقرار نیست — داده‌های پیشین ممکن است قدیمی باشند"+(error.isEmpty()?"":" | "+error));
            statusText.setTextColor(YELLOW);
        }
        if(footerText!=null){
            String updated=lastSyncedMs>0?new SimpleDateFormat("HH:mm:ss",Locale.ROOT){{setTimeZone(TimeZone.getTimeZone("Asia/Tehran"));}}.format(new Date(lastSyncedMs)):"بدون دریافت قبلی";
            footerText.setText("آخرین داده معتبر: "+updated+"  |  باستیان کیوسک R105  |  اتصال مستقیم HTTPS");
        }
    }
    private void rebuildCards(){
        if(cardHost==null)return;
        if(mediaPanel!=null&&api!=null)mediaPanel.configure(lastState,api.origin(),token,connected);
        cardHost.removeAllViews();
        if(lastState==null){
            emptyCard("در حال برقراری ارتباط ایمن با مرکز", "لطفاً کمی بعد دوباره بررسی کنید");return;
        }
        JSONArray doctors=lastState.optJSONArray("doctors"),queues=lastState.optJSONArray("queues");
        if(doctors==null||doctors.length()==0){
            emptyCard("نمایشگر آماده است", "هنوز پزشکی برای این مرکز تعریف نشده است");return;
        }
        int count=doctors.length();int columns=tv?(count==1?1:Math.min(3,count)):1;
        for(int first=0;first<count;first+=columns){
            LinearLayout row=horizontal();row.setGravity(Gravity.CENTER);cardHost.addView(row,new LinearLayout.LayoutParams(-1,-2));
            for(int idx=first;idx<Math.min(first+columns,count);idx++){
                JSONObject doc=doctors.optJSONObject(idx);if(doc==null)continue;
                String did=doc.optString("id"),name=doc.optString("name","پزشک مرکز");
                String spec=doc.optString("specialty","");
                JSONObject active=null;int waiting=0;
                if(queues!=null)for(int n=0;n<queues.length();n++){
                    JSONObject q=queues.optJSONObject(n);if(q==null||!did.equals(q.optString("doctorId")))continue;
                    if(!q.optBoolean("isActive",true))continue;
                    String state=q.optString("status","waiting");
                    if("waiting".equals(state))waiting++;
                    if("calling".equals(state))active=q;
                }
                LinearLayout card=vertical();card.setGravity(Gravity.CENTER);pad(card,tv?17:15,tv?20:14);
                boolean call=active!=null;
                card.setBackgroundColor(call?Color.rgb(40,54,50):SURFACE);
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(tv?340:225),1);
                cp.setMargins(dp(8),dp(8),dp(8),dp(8));row.addView(card,cp);
                TextView docText=label(name,tv?27:21,TEXT,true);docText.setGravity(Gravity.CENTER);
                append(card,docText,tv?62:42);
                if(!spec.isEmpty()){
                    TextView specialty=label(spec,tv?17:13,SUB,false);specialty.setGravity(Gravity.CENTER);
                    append(card,specialty,tv?35:25);
                }
                int ticket=active==null?0:ticket(active);
                TextView number=label(ticket>0?digits(ticket):"—",tv?(count==1?130:85):68,call?YELLOW:CYAN,true);
                number.setGravity(Gravity.CENTER);card.addView(number,new LinearLayout.LayoutParams(-1,0,1));
                TextView caption=label(call?"نوبت فراخوان‌شده":"در انتظار فراخوان",tv?23:17,call?YELLOW:TEXT,true);
                caption.setGravity(Gravity.CENTER);append(card,caption,tv?44:34);
                TextView waitingText=label("تعداد در انتظار: "+digits(waiting),tv?18:14,SUB,false);
                waitingText.setGravity(Gravity.CENTER);append(card,waitingText,tv?35:29);
            }
        }
        String message="لطفاً به اعلام شماره نوبت توجه فرمایید";
        JSONArray tickers=lastState.optJSONArray("tickers");
        if(tickers!=null&&tickers.length()>0){
            StringBuilder m=new StringBuilder();
            for(int i=0;i<Math.min(6,tickers.length());i++){
                Object item=tickers.opt(i);
                String t=item instanceof JSONObject?((JSONObject)item).optString("text",((JSONObject)item).optString("message","")):
                    item instanceof String?(String)item:"";
                if(!t.trim().isEmpty()){if(m.length()>0)m.append("    •    ");m.append(t.trim());}
            }
            if(m.length()>0)message=m.toString();
        }
        if(tickerText!=null)tickerText.setText(message);
    }
    private void emptyCard(String title,String detail){
        LinearLayout card=vertical();pad(card,30,40);card.setGravity(Gravity.CENTER);card.setBackgroundColor(SURFACE);
        cardHost.addView(card,new LinearLayout.LayoutParams(-1,dp(tv?360:280)));
        TextView t=label(title,tv?34:24,YELLOW,true);t.setGravity(Gravity.CENTER);append(card,t,85);
        TextView s=label(detail,tv?21:16,SUB,false);s.setGravity(Gravity.CENTER);append(card,s,85);
    }
    private static int ticket(JSONObject q){
        int n=q.optInt("number",q.optInt("queueNumber",q.optInt("ticketNumber",0)));
        if(n<1){try{n=Integer.parseInt(q.optString("number").replaceAll("[^0-9]",""));}catch(Exception ignored){}}
        return n;
    }
    private static String digits(int n){String s=Integer.toString(n),en="0123456789",fa="۰۱۲۳۴۵۶۷۸۹";
        for(int i=0;i<10;i++)s=s.replace(en.charAt(i),fa.charAt(i));return s;}
    private void checkCall(JSONObject call){
        String id=call.optString("callId","");if(id.isEmpty()||!connected||!vault.audioEnabled())return;
        long created=call.optLong("createdAtMs",call.optLong("timestamp",0));long now=System.currentTimeMillis();
        if(created<1_000_000_000_000L||created>now+30000||now-created>1_200_000L)return;
        if(id.equals(ackPending)){sendAck(id);return;}
        if(id.equals(lastCallId)||announcer.isPlaying())return;
        int number=ticket(call);
        if(number<1||number>9999){refreshStatus("شماره فراخوان خارج از محدوده صوت آفلاین است");return;}
        // Only a completed, real audio playback may acknowledge server call.
        if(mediaPanel!=null){mediaPanel.showCall(number);mediaPanel.setAnnouncementActive(true);}
        announcer.play(number,(ok,why)->{
            if(mediaPanel!=null)mediaPanel.setAnnouncementActive(false);
            if(!id.equals(call.optString("callId"))||!displaying)return;
            if(ok){lastCallId=id;vault.markPlayed(id);ackPending=id;sendAck(id);}
            else refreshStatus("فراخوان شنیده نشد؛ تأیید صوتی ارسال نشد: "+why);
        });
    }
    private void sendAck(String id){
        if(id.isEmpty()||api==null||token.isEmpty()||!connected)return;
        final KioskApi currentApi=api;final String sessionToken=token;
        io.execute(()->{
            try{currentApi.complete(sessionToken,id);ui.post(()->{if(id.equals(ackPending))ackPending="";});}
            catch(Exception ignored){/* Keep ackPending, retry on the next authorized poll. */}
        });
    }
    private static String humanError(Exception e){
        if(e instanceof KioskApi.ApiException){
            KioskApi.ApiException a=(KioskApi.ApiException)e;
            if(a.httpStatus==401)return "نشست منقضی یا نامعتبر شده است";
            if(a.httpStatus==404)return "مسیر API در سرور پیدا نشد؛ آدرس را بررسی کنید";
            return a.getMessage()==null?"خطای سرور ("+a.httpStatus+")":a.getMessage();
        }
        String m=e.getMessage()==null?"":e.getMessage();
        if(e instanceof java.net.UnknownHostException)return "دامنه سرور پیدا نشد؛ DNS یا اینترنت را بررسی کنید";
        if(e instanceof java.net.SocketTimeoutException)return "سرور در مهلت مشخص پاسخ نداد";
        if(e instanceof javax.net.ssl.SSLException)return "گواهی امنیتی HTTPS سرور قابل تأیید نیست";
        if(e instanceof java.net.ConnectException)return "اتصال به سرور برقرار نشد؛ شبکه یا سرور را بررسی کنید";
        return m.isEmpty()?"ارتباط با سامانه برقرار نشد":m;
    }
}
