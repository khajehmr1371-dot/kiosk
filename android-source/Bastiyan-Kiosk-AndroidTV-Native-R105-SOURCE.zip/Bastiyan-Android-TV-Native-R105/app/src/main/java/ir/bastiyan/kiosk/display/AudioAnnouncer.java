package ir.bastiyan.kiosk.display;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayDeque;
import java.util.List;

/** All numbers 1..9999 play from bundled MP3 assets. No TTS engine or WebView. */
final class AudioAnnouncer {
    interface Completion { void finished(boolean success,String reason); }
    private final Context ctx;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ArrayDeque<String> queue=new ArrayDeque<>();
    private MediaPlayer current;
    private Completion callback;
    private int generation=0;
    private int remaining=0;
    AudioAnnouncer(Context ctx){this.ctx=ctx.getApplicationContext();}
    boolean isPlaying(){return callback!=null;}
    void stop(){
        generation++;
        callback=null;queue.clear();remaining=0;
        if(current!=null){try{current.stop();}catch(Exception ignored){}current.release();current=null;}
    }
    void play(int number,Completion cb){
        stop();
        AudioManager audio=(AudioManager)ctx.getSystemService(Context.AUDIO_SERVICE);
        if(audio==null||audio.getStreamVolume(AudioManager.STREAM_MUSIC)<=0){
            cb.finished(false,"صدای رسانه دستگاه صفر یا در دسترس نیست؛ صدا را از تنظیمات تلویزیون فعال کنید");return;
        }
        if(number<1||number>9999){cb.finished(false,"شماره نوبت خارج از محدوده صوت آفلاین است (۱ تا ۹۹۹۹)");return;}
        callback=cb;
        List<String> parts=Numbers.files(number);
        for(int repetition=0;repetition<2;repetition++){
            for(String part:parts)queue.add(part);
            if(repetition==0)queue.add("");
        }
        remaining=queue.size();
        next(generation);
    }
    private void next(int expected){
        if(expected!=generation||callback==null)return;
        if(current!=null){current.release();current=null;}
        if(queue.isEmpty()){
            Completion cb=callback;callback=null;
            cb.finished(true,"");return;
        }
        String asset=queue.remove();remaining--;
        if(asset.isEmpty()){
            handler.postDelayed(()->next(expected),700);return;
        }
        MediaPlayer player=new MediaPlayer();current=player;
        try(AssetFileDescriptor afd=ctx.getAssets().openFd(asset)){
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
            player.setOnCompletionListener(p->handler.postDelayed(()->next(expected),partsDelay()));
            player.setOnErrorListener((p,what,extra)->{fail(expected,"خطای پخش صوت: "+what);return true;});
            player.prepare();
            player.start();
        }catch(Exception e){
            player.release();current=null;
            fail(expected,"فایل صوتی قابل پخش نیست: "+asset);
        }
    }
    private long partsDelay(){return remaining<=1?150:170;}
    private void fail(int expected,String why){
        if(expected!=generation)return;
        Completion cb=callback;
        stop();
        if(cb!=null)cb.finished(false,why);
    }
}
