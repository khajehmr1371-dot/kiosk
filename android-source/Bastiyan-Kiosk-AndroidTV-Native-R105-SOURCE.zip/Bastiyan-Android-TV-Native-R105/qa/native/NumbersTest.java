import ir.bastiyan.kiosk.display.Numbers;
import java.util.List;
public final class NumbersTest{
 static void test(int n,String... expected){
   List<String> got=Numbers.files(n);
   if(got.size()!=expected.length)throw new AssertionError("size "+n+":"+got);
   for(int i=0;i<expected.length;i++)if(!expected[i].equals(got.get(i)))throw new AssertionError("number "+n+": "+got);
 }
 public static void main(String[]args){
   test(1,"audio/N01.mp3");
   test(50,"audio/N50.mp3");
   test(51,"words/number.mp3","words/50.mp3","words/and.mp3","words/1.mp3");
   test(112,"words/number.mp3","words/100.mp3","words/and.mp3","words/12.mp3");
   test(567,"words/number.mp3","words/500.mp3","words/and.mp3","words/60.mp3","words/and.mp3","words/7.mp3");
   test(1001,"words/number.mp3","words/1.mp3","words/1000.mp3","words/and.mp3","words/1.mp3");
   test(9999,"words/number.mp3","words/9.mp3","words/1000.mp3","words/and.mp3","words/900.mp3","words/and.mp3","words/90.mp3","words/and.mp3","words/9.mp3");
   try {Numbers.files(10000); throw new AssertionError("invalid 10000");}catch(IllegalArgumentException expected){}
   System.out.println("PASS: 8 offline Persian number token tests");
 }
}
