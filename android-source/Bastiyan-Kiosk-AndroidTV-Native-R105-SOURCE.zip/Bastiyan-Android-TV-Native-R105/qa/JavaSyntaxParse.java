import java.util.Arrays;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import com.sun.source.util.JavacTask;

public class JavaSyntaxParse {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if(compiler==null)throw new IllegalStateException("JDK compiler unavailable");
    try(StandardJavaFileManager files=compiler.getStandardFileManager(null,null,null)){
      Iterable<? extends JavaFileObject> sources=files.getJavaFileObjectsFromStrings(Arrays.asList(args));
      JavacTask task=(JavacTask)compiler.getTask(null,files,null,Arrays.asList("-proc:none"),null,sources);
      int count=0;
      for(var ignored:task.parse())count++;
      System.out.println("Parsed "+count+" Android Java translation units");
    }
  }
}
