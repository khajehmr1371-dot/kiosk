from pathlib import Path
from xml.etree import ElementTree
import subprocess,json,hashlib,shutil,re,sys,tempfile
R=Path(__file__).resolve().parents[1]
report={'product':'Bastiyan Kiosk Native Android TV','release':'R105','apkBuilt':False,'liveServerTested':False,'deviceTested':False}
java_files=list((R/'app/src/main/java').rglob('*.java'))
report['javaFiles']=len(java_files)
assert len(java_files)>=6
manifest=ElementTree.parse(R/'app/src/main/AndroidManifest.xml').getroot()
xml=(R/'app/src/main/AndroidManifest.xml').read_text()
for required in ['android.software.leanback','android.hardware.touchscreen','LEANBACK_LAUNCHER','android.permission.INTERNET','android:usesCleartextTraffic="false"']:
 assert required in xml,required
report['manifest']='PASS'
voices=list((R/'app/src/main/assets/audio').glob('N*.mp3'))
for i in range(1,51):assert (R/f'app/src/main/assets/audio/N{i:02d}.mp3').is_file()
words=list((R/'app/src/main/assets/words').glob('*.mp3'))
assert len(words)>=39
report['bundledVoiceFiles']={'recordedNumbers':len(voices),'offlineFragments':len(words),'total':len(voices)+len(words)}
for f in voices+words:
 assert f.stat().st_size>1000
 # ffprobe optional on developer workstation; this container has it.
 if shutil.which('ffprobe'):
  out=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(f)],text=True).strip()
  assert float(out)>0.1, f
report['audioIntegrity']='PASS'
all_src='\n'.join(f.read_text() for f in java_files)
for bad in ['new WebView(', 'import android.webkit.WebView','Runtime.getRuntime().exec(', 'http://']:
 assert bad not in all_src,bad
report['noWebViewOrShell']='PASS'
for needed in ['auth/display-login','session/keepalive','announcements/complete','state','sync/poll?version=']:
 assert needed in all_src,needed
report['apiContract']='PASS'
# Parser-only check (no SDK)
with tempfile.TemporaryDirectory(prefix='bastiyan-qa-') as tmp:
 subprocess.check_call(['javac','-d',tmp,str(R/'qa/JavaSyntaxParse.java')])
 subprocess.check_call(['java','-cp',tmp,'JavaSyntaxParse']+[str(p) for p in java_files])
report['javaParser']='PASS'
# Full type checking against mock Android *signatures* is not equivalent to compiling with SDK.
subprocess.check_call([sys.executable,str(R/'qa/typecheck_with_stubs.py')])
report['mockAndroidTypeCheck']='PASS'
with tempfile.TemporaryDirectory(prefix='bastiyan-number-qa-') as tmp:
 subprocess.check_call(['javac','-d',tmp,str(R/'app/src/main/java/ir/bastiyan/kiosk/display/Numbers.java'),str(R/'qa/native/NumbersTest.java')])
 subprocess.check_call(['java','-cp',tmp,'NumbersTest'])
report['offlineNumberTests']='PASS'
report['sdkAvailable']=bool(shutil.which('aapt2') and shutil.which('gradle'))
report['supportedMinAndroid']='Android 6.0 (API 23)'
report['knownLimitations']=['No APK build in this environment: Android SDK/build-tools unavailable','Not tested on live Chabokan server or Android hardware','PDF/Office media renders queue fallback','Media codecs vary by hardware','Live queue needs reachable HTTPS server']
(R/'qa/QA_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('QA summary:',json.dumps(report,ensure_ascii=False,indent=2))
